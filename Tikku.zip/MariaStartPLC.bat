@echo off
setlocal

set "ROOT=%~dp0"
set "MARIADB=%ROOT%mariadb-11.8.3-winx64"
set "BIN=%MARIADB%\bin"

echo Starting MariaDB...

if not exist "%BIN%\mariadbd.exe" (
    echo ERROR: mariadbd.exe not found!
    pause
    exit /b 1
)

cd /d "%BIN%"

start "MariaDB" cmd /c ""%BIN%\mariadbd.exe" --basedir="%MARIADB%" --datadir="%MARIADB%\data" --console"

endlocal
