@echo off
setlocal

set "ROOT=%~dp0"
set "BIN=%ROOT%mariadb-11.8.3-winx64\bin"

echo Stopping MariaDB...

if not exist "%BIN%\mariadb-admin.exe" (
    echo ERROR: mariadb-admin.exe not found!
    pause
    exit /b 1
)

"%BIN%\mariadb-admin.exe" -u root -p shutdown

if %errorlevel%==0 (
    echo MariaDB stopped successfully.
) else (
    echo ERROR: MariaDB shutdown failed!
)

endlocal
pause
